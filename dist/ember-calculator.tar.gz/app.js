server = require("./server.js");
config = require("./config");
server.startServer(config, function(){});
